﻿#include <iostream>
using namespace std;

int main() {
    freopen("fairy.in", "r", stdin);
    freopen("fairy.out", "w", stdout);

    return 0;
}
﻿#include <iostream>
#include <vector>
using namespace std;
struct node {
	int x,y,z;
	bool error() {
		return x==-1 && y==-1 && z==-1;
	}
	bool operator==(node b) {
		return this->x==b.x && this->y==b.y && this->z==b.z;
	}
};
const int N=110;
int a[N][N];
int vec[N][N][N];
int idx,idy[N],idz[N][N];
int n,m,k;
//void remv(int x,int y,int z) { //将下一个可使用位置转变为{x,y,z}
//	idx=x;
//	idy[idx]=1, idz[idy[idx]]=1;
//}
node find(int sz) { //可用位置
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			if(a[i][j]!=sz) continue;
			for(int l=1;l<=k;l++) {
				if(!vec[i][j][l]) {
					return {i,j,l};
				}
			}
		}
	}
	return {-1,-1,-1};
}
int main() {
  freopen("express.in","r",stdin);
  freopen("express.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			cin>>a[i][j];
		}
	}
	int t;
	cin>>t;
	while(t--) {
		int op;
		cin>>op;
		if(op==1) {
			int x;
			cin>>x;
			node f=find(x);
			vec[f.x][f.y][f.z]=x;
		}else {
			int x,y,z;
			scanf("%d-%d-%d",&x,&y,&z);
			
		}
	}
  return 0;
}
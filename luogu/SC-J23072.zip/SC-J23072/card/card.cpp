#include <iostream>
using namespace std;

const int N = 1e5 + 3;
int p[N];
bool vis[N];

int gcd(int a, int b) {
	if (!b) {
		return a;
	}
	return gcd(b, a % b);
}

int lcm(int a, int b) {
	return a / gcd(a, b) * b;
}

int find(int st) {
	int cur = st;
	int cnt = 0;
	while (1) {
		cur = p[cur - 1];
		cnt++;
		if (cur == st) {
			break;
		}
	}
	return cnt;
}

int main() {
	freopen("card.in","r",stdin);
	freopen("card.out","w",stdout);
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> p[i];
	}

	int res = 1;
	for (int i = 1; i <= n; i++) {
		if (!vis[i - 1]) {
			int len = find(i);
			res = lcm(res, len);
			vis[i - 1] = 1;
		}
	}
	cout << res;
	return 0;
}